# -*- coding: utf-8 -*-
# 11_visual_notes.rpy
# 《知识冢》视觉设计备注 —— 本文件不参与剧情，仅保存开发备忘

## 整体视觉原则：
# 1. 恐怖的是过去，不是故乡。
# 2. 白天场景要温暖、生活化。
# 3. 夜晚场景要压抑，但不要鬼片化。
# 4. 山沟旧址要安静、沉重，不要血腥。
# 5. 老人不是恐怖元素，贫穷和没有选择才是恐怖来源。

## 第一批背景：
# bg_yard.png     — 老家院子，温暖怀旧
# bg_field.png    — 田地，黑土，小路通向山沟
# bg_old_house.png— 老屋堂屋，爷爷讲故事
# bg_storage.png  — 杂物间，麻袋、破碗、半块砖
# bg_kitchen.png  — 母亲批改作业，现实感
# bg_gully.png    — 山沟旧址，一日一饭一日一砖

## 第一批 CG：
# cg_sack.png        — 旧麻袋特写
# cg_bowl.png        — 破饭碗特写
# cg_brick.png       — 半块砖特写
# cg_stone_words.png — 山沟石刻特写
