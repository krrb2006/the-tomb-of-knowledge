# -*- coding: utf-8 -*-
# 07_ui_style.rpy
# 《知识冢》轻量 UI 风格修复版
# 目标：固定对话框在屏幕底部，避免跑到左上角

init python:
    # 中文阅读字号
    gui.text_size = 28
    gui.name_text_size = 30

    # 颜色
    gui.text_color = "#E8E1D2"
    gui.interface_text_color = "#E8E1D2"
    gui.hover_color = "#FFCC66"
    gui.selected_color = "#D6B873"


# ------------------------------------------------------------
# 对话框窗口：固定在屏幕底部
# ------------------------------------------------------------

style say_window:
    xalign 0.5
    yalign 1.0
    xfill True
    ysize 280
    background "#120F0BCC"


# ------------------------------------------------------------
# 角色名框
# ------------------------------------------------------------

style namebox:
    xpos 330
    ypos 18
    xsize 260
    ysize 48
    background "#00000099"
    padding (14, 6)


style say_label:
    xalign 0.5
    yalign 0.5
    size 30
    color "#D6B873"
    outlines [(1, "#000000cc", 0, 0)]


# ------------------------------------------------------------
# 对话文本
# ------------------------------------------------------------

style say_dialogue:
    xpos 360
    ypos 82
    xsize 1200
    size 28
    color "#E8E1D2"
    line_spacing 6
    outlines [(1, "#00000099", 0, 0)]


# ------------------------------------------------------------
# 选项按钮文本
# ------------------------------------------------------------

style choice_button_text:
    size 28
    color "#E8E1D2"
    hover_color "#FFCC66"
    selected_color "#D6B873"
