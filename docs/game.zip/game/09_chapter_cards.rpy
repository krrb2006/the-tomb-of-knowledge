# -*- coding: utf-8 -*-
# 09_chapter_cards.rpy
# 章节标题卡 —— 每章开头调用，增强节奏感

label chapter_card(title, subtitle=""):
    scene bg black
    with fade
    pause 0.2
    centered "{size=46}{color=#D6B873}[title]{/color}{/size}"
    if subtitle != "":
        pause 0.4
        centered "{size=26}{color=#B8B0A0}[subtitle]{/color}{/size}"
    pause 0.8
    return
