# -*- coding: utf-8 -*-
# 02_assets.rpy
# 视觉资源定义：图片存在则使用图片，不存在则使用纯色占位
# 添加新背景只需：safe_image("bg xxx", "images/bg/bg_xxx.png", "#hexcolor")

init python:
    def safe_image(name, path, fallback_color):
        """安全注册图像：文件存在用图片（自适应缩放），不存在用纯色兜底"""
        if renpy.loadable(path):
            renpy.image(name, Transform(path, fit="contain"))
        else:
            renpy.image(name, Solid(fallback_color))

# 基础背景（不需要文件）
image bg black = Solid("#050505")

# 场景背景
init python:
    safe_image("bg title",    "images/ui/title_bg.png",         "#080806")
    safe_image("bg yard",     "images/bg/bg_yard.png",          "#2b241c")
    safe_image("bg field",    "images/bg/bg_field.png",         "#1f2a18")
    safe_image("bg old_house","images/bg/bg_old_house.png",     "#201914")
    safe_image("bg storage",  "images/bg/bg_storage.png",       "#16120f")
    safe_image("bg kitchen",  "images/bg/bg_kitchen.png",       "#231c17")
    safe_image("bg gully",    "images/bg/bg_gully.png",         "#090909")
    safe_image("bg village",  "images/bg/bg_village.png",       "#242424")
    safe_image("bg night",    "images/bg/bg_night_yard.png",    "#08090d")
    safe_image("bg morning",  "images/bg/bg_morning_field.png", "#262018")
    safe_image("bg future",   "images/bg/bg_future_village.png","#202820")
    safe_image("bg memory",   "images/bg/bg_old_house.png",     "#1a1512")

# CG 特写（暂无图片时用暗色兜底）
init python:
    safe_image("cg sack",        "images/cg/cg_sack.png",        "#16120f")
    safe_image("cg bowl",        "images/cg/cg_bowl.png",        "#16120f")
    safe_image("cg brick",       "images/cg/cg_brick.png",       "#16120f")
    safe_image("cg stone_words", "images/cg/cg_stone_words.png", "#090909")

# UI 遮罩（暂无图片时透明）
init python:
    safe_image("overlay vignette", "images/ui/overlay_vignette.png", "#00000000")
