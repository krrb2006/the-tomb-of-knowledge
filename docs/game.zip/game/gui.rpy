﻿# gui.rpy — 分辨率与 GUI 基础配置

init -1 python:
    gui.init(1280, 720)

# 字体配置在 00_settings_cn.rpy
# UI 风格微调在 07_ui_style.rpy
