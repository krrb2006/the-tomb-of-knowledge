# -*- coding: utf-8 -*-
# screens.rpy — 中文界面

## 主菜单
screen main_menu():
    tag menu
    add "#000000"
    vbox:
        xalign 0.5
        yalign 0.5
        spacing 20
        textbutton "开始游戏" action Start()
        textbutton "读取存档" action ShowMenu("load")
        textbutton "设置"     action ShowMenu("preferences")
        textbutton "退出"     action Quit(confirm=False)

## 导航
screen navigation():
    vbox:
        xpos 40
        yalign 0.5
        spacing 20
        textbutton "返回"       action Return()
        textbutton "存档"       action ShowMenu("save")
        textbutton "读档"       action ShowMenu("load")
        textbutton "设置"       action ShowMenu("preferences")
        textbutton "标题画面"   action MainMenu()
        textbutton "退出"       action Quit()

## 存档 / 读档
screen save():
    tag menu
    use file_slots("存档")

screen load():
    tag menu
    use file_slots("读档")

screen file_slots(title):
    use game_menu(title):
        vbox:
            hbox:
                textbutton "自动" action FilePage("auto")
                textbutton "快速" action FilePage("quick")
                for i in range(1, 10):
                    textbutton str(i) action FilePage(i)
            grid gui.file_slot_cols gui.file_slot_rows:
                for i in range(gui.file_slot_cols * gui.file_slot_rows):
                    $ slot = i + 1
                    button:
                        action FileAction(slot)
                        vbox:
                            add FileScreenshot(slot) xalign 0.5
                            text FileTime(slot, empty="空存档")
                            text FileSaveName(slot)
                        key "save_delete" action FileDelete(slot)

## 设置
screen preferences():
    tag menu
    use game_menu("设置"):
        vbox:
            hbox:
                if renpy.variant("pc") or renpy.variant("web"):
                    vbox:
                        label "显示模式"
                        textbutton "窗口" action Preference("display", "window")
                        textbutton "全屏" action Preference("display", "fullscreen")
            null height 20
            hbox:
                vbox:
                    label "文字速度"
                    bar value Preference("text speed")
                vbox:
                    label "自动阅读"
                    bar value Preference("auto-forward time")
            null height 20
            hbox:
                vbox:
                    label "音乐音量"
                    bar value Preference("music volume")
                vbox:
                    label "音效音量"
                    bar value Preference("sound volume")

## 游戏菜单框架
screen game_menu(title, scroll=None, yinitial=0.0):
    add "#1A1A1A"
    frame:
        xalign 0.5
        yalign 0.45
        xpadding 40
        ypadding 30
        vbox:
            spacing 20
            label title:
                xalign 0.5
                text_align 0.5
            transclude
    use navigation
    textbutton "返回":
        xpos 40
        yalign 0.99
        yoffset -40
        action Return()

## 确认
screen confirm(message, yes_action, no_action):
    modal True
    zorder 200
    frame:
        xalign 0.5
        yalign 0.45
        xpadding 40
        ypadding 30
        vbox:
            spacing 20
            text message:
                xalign 0.5
                text_align 0.5
            hbox:
                xalign 0.5
                spacing 30
                textbutton "是" action yes_action
                textbutton "否" action no_action
    key "game_menu" action no_action

## 快捷菜单
screen quick_menu():
    zorder 100
    if quick_menu:
        hbox:
            xalign 0.5
            yalign 1.0
            spacing 10
            textbutton "回退"  action Rollback()
            textbutton "存档"  action ShowMenu("save")
            textbutton "快进"  action Skip()
            textbutton "自动"  action Preference("auto-forward", "toggle")
            textbutton "设置"  action ShowMenu("preferences")

## 输入框
screen input(prompt):
    window:
        vbox:
            xalign 0.5
            yalign 0.5
            text prompt
            input id "input"

## 选择
screen choice(items):
    vbox:
        xalign 0.5
        yalign 0.5
        spacing 10
        for i in items:
            textbutton i.caption action i.action
